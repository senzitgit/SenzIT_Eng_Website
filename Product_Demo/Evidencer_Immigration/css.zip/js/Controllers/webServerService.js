/*var webServerUrl = "https://immigration.mybluemix.net/AppServerService.jsp";
var changePicUrl = "https://immigration.mybluemix.net/ChangePictureService.jsp";*/

var webServerUrl = "http://localhost:8081/Immigration/AppServerService.jsp";
var changePicUrl = "http://localhost:8081/Immigration/ChangePictureService.jsp"; 


DownloadUrl = "C://apache-tomcat-7.0.54//webapps//Rebbon//CaseRecords";

