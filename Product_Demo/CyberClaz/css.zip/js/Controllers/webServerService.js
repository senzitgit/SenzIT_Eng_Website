

var webServerUrl = "https://clazportal.mybluemix.net/AppServerService.jsp";
var changePicUrl = "https://clazportal.mybluemix.net/ChangePictureService.jsp";
var libraryUploadUrl = "https://clazportal.mybluemix.net/UploadFileService.jsp";
var webSocketIp="clazserver.mybluemix.net";



/*
var webServerUrl = "http://localhost:8081/ClazPortal/AppServerService.jsp";
var changePicUrl = "http://localhost:8081/ClazPortal/ChangePictureService.jsp";
var libraryUploadUrl = "http://localhost:8081/ClazPortal/UploadFileService.jsp";
var webSocketIp="192.168.10.50:8080/CyberClazServer"; 
*/
