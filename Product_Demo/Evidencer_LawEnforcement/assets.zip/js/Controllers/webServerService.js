/*var webServerUrl = "https://lande.mybluemix.net/AppServerService.jsp";
var changePicUrl = "https://lande.mybluemix.net/ChangePictureService.jsp";*/

var webServerUrl = "http://localhost:8081/LawAndEnforcement/AppServerService.jsp";
var changePicUrl = "http://localhost:8081/LawAndEnforcement/ChangePictureService.jsp";


DownloadUrl = "C://apache-tomcat-7.0.54//webapps//Rebbon//CaseRecords";

